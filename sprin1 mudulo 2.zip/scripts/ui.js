// export const  = (arrayChats) => {
//     smallCardsContainer.innerHTML ="";
//     arrayChats.forEach((cuenta) => {
//         smallCardsContainer.innerHTML += `
//         <article class="aside-container__chats-card">
//             <figure><img src="${cuenta.foto}" alt="${cuenta.nombre}"></figure>
//             <div class="aside-container__chat-info">
//                 <div class="aside-container__chat-info1">
//                     <h3>${cuenta.nombre}</h3>
//                     <p>${cuenta.coversaciones}</p>
//                     <div class="aside-container__chat-preview">
//                         <figure><img src="./01 ICONS/check.svg" alt=""></figure>
//                         <p >${cuenta.coversaciones}</p>
//                     </div>
//                 </div>
            
//             </div>
//     </article>`;
//     });

// }

export const renderSmallCards = (container, contactList) => {
    container.innerHTML = "";
    contactList.forEach((contact, index) => {
        container.innerHTML += `
        <article class="aside-container__chats-card" name=${contact.id} data-index=${index} id="${contact.id}">
            <figure><img src="${contact.foto}" alt="${contact.nombre}"></figure>
            <div class="aside-container__chat-info">
                <div class="aside-container__chat-info1">
                    <h3>${contact.nombre}</h3>
                    <p>gg2</p>
                    <div class="aside-container__chat-preview">
                        <figure><img src="./01 ICONS/check.svg" alt=""></figure>
                        <p >gg</p>
                    </div>
                </div>
            
            </div>
    </article>`;
    })
}

export const renderProfileCard = (cuentas) => {
    profileCard.innerHTML = ''
    profileCard.innerHTML = `
    <figure><img src="${cuentas.foto}" alt="img"></figure>
    <p>Tu nombre</p>
    <h3>${cuentas.nombre}</h3>
    <p>Info.</p>
    <h3>${cuentas.info}</h3>
    `
}

export const rendercharacterProfileCard = (cuentas) => {
    characterProfileCard.innerHTML = ''
    characterProfileCard.innerHTML = `
        <figure><img src="${cuentas.foto}" alt="img"></figure>
        <h2>${cuentas.nombre}</h2>
        <p>Info.</p>
        <h3>${cuentas.info}</h3>
    `
}

export const renderConversations = ( menssengers, container, idUserLogged) => {
    container.innerHTML = '';
    menssengers.forEach((menssenger, index) => {
        container.innerHTML += `
            <section class=${menssenger.sendBy === idUserLogged? 'conversation--me': 'conversation--friend'}>${
          menssenger.menssenges
        }</section>
        `;
    })
};